package com.example.demo.entity;

public enum OrderStatus {
    PENDING,
    COMPLETED,
    CANCELLED
}
